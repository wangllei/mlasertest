/****************************************************************************
** Meta object code from reading C++ file 'uimanager.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "E:/mlaser/mLaser1.0/MLaser/UICompment/uimanager.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'uimanager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_UIManager_t {
    QByteArrayData data[45];
    char stringdata[566];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_UIManager_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_UIManager_t qt_meta_stringdata_UIManager = {
    {
QT_MOC_LITERAL(0, 0, 9),
QT_MOC_LITERAL(1, 10, 19),
QT_MOC_LITERAL(2, 30, 0),
QT_MOC_LITERAL(3, 31, 15),
QT_MOC_LITERAL(4, 47, 14),
QT_MOC_LITERAL(5, 62, 17),
QT_MOC_LITERAL(6, 80, 9),
QT_MOC_LITERAL(7, 90, 8),
QT_MOC_LITERAL(8, 99, 10),
QT_MOC_LITERAL(9, 110, 17),
QT_MOC_LITERAL(10, 128, 14),
QT_MOC_LITERAL(11, 143, 11),
QT_MOC_LITERAL(12, 155, 16),
QT_MOC_LITERAL(13, 172, 21),
QT_MOC_LITERAL(14, 194, 12),
QT_MOC_LITERAL(15, 207, 6),
QT_MOC_LITERAL(16, 214, 6),
QT_MOC_LITERAL(17, 221, 6),
QT_MOC_LITERAL(18, 228, 6),
QT_MOC_LITERAL(19, 235, 6),
QT_MOC_LITERAL(20, 242, 6),
QT_MOC_LITERAL(21, 249, 8),
QT_MOC_LITERAL(22, 258, 15),
QT_MOC_LITERAL(23, 274, 11),
QT_MOC_LITERAL(24, 286, 14),
QT_MOC_LITERAL(25, 301, 1),
QT_MOC_LITERAL(26, 303, 17),
QT_MOC_LITERAL(27, 321, 17),
QT_MOC_LITERAL(28, 339, 9),
QT_MOC_LITERAL(29, 349, 8),
QT_MOC_LITERAL(30, 358, 10),
QT_MOC_LITERAL(31, 369, 14),
QT_MOC_LITERAL(32, 384, 3),
QT_MOC_LITERAL(33, 388, 14),
QT_MOC_LITERAL(34, 403, 11),
QT_MOC_LITERAL(35, 415, 16),
QT_MOC_LITERAL(36, 432, 21),
QT_MOC_LITERAL(37, 454, 12),
QT_MOC_LITERAL(38, 467, 10),
QT_MOC_LITERAL(39, 478, 12),
QT_MOC_LITERAL(40, 491, 16),
QT_MOC_LITERAL(41, 508, 12),
QT_MOC_LITERAL(42, 521, 14),
QT_MOC_LITERAL(43, 536, 12),
QT_MOC_LITERAL(44, 549, 16)
    },
    "UIManager\0Sig_FrontEndCombine\0\0"
    "Sig_FrontEndCMD\0Sig_SerialPort\0"
    "Sig_SerialConnect\0Sig_Print\0Sig_Stop\0"
    "Sig_Cancle\0Sig_FinishPersent\0"
    "Sig_ProcessBar\0Sig_Recover\0Sig_ConnectFaile\0"
    "Sig_ConnectFirstFaile\0Sig_Bounding\0"
    "slotAA\0slotAB\0slotAC\0slotAD\0slotAE\0"
    "slotAF\0slotMWin\0slotCombinrFile\0"
    "slotToLaser\0slotSerialPort\0m\0"
    "slotSerialConnect\0slotFinishPersent\0"
    "slotPrint\0slotStop\0slotCancle\0"
    "slotServerLoad\0cmd\0slotProcessBar\0"
    "slotRecover\0slotConnectFaile\0"
    "slotConnectFirstFaile\0slotShowLoad\0"
    "slotLoadIn\0slotBounding\0slotAGSuccessful\0"
    "slotAGFailed\0slotAHNextStep\0slotLoadNext\0"
    "slotEndStopState"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_UIManager[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      41,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      13,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  219,    2, 0x06 /* Public */,
       3,    1,  222,    2, 0x06 /* Public */,
       4,    1,  225,    2, 0x06 /* Public */,
       5,    1,  228,    2, 0x06 /* Public */,
       6,    0,  231,    2, 0x06 /* Public */,
       7,    0,  232,    2, 0x06 /* Public */,
       8,    0,  233,    2, 0x06 /* Public */,
       9,    1,  234,    2, 0x06 /* Public */,
      10,    2,  237,    2, 0x06 /* Public */,
      11,    0,  242,    2, 0x06 /* Public */,
      12,    1,  243,    2, 0x06 /* Public */,
      13,    1,  246,    2, 0x06 /* Public */,
      14,    1,  249,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      15,    1,  252,    2, 0x0a /* Public */,
      16,    1,  255,    2, 0x0a /* Public */,
      17,    1,  258,    2, 0x0a /* Public */,
      18,    1,  261,    2, 0x0a /* Public */,
      19,    1,  264,    2, 0x0a /* Public */,
      20,    1,  267,    2, 0x0a /* Public */,
      21,    1,  270,    2, 0x0a /* Public */,
      22,    1,  273,    2, 0x0a /* Public */,
      23,    1,  276,    2, 0x0a /* Public */,
      24,    1,  279,    2, 0x0a /* Public */,
      26,    1,  282,    2, 0x0a /* Public */,
      27,    1,  285,    2, 0x0a /* Public */,
      28,    0,  288,    2, 0x0a /* Public */,
      29,    0,  289,    2, 0x0a /* Public */,
      30,    0,  290,    2, 0x0a /* Public */,
      31,    1,  291,    2, 0x0a /* Public */,
      33,    2,  294,    2, 0x0a /* Public */,
      34,    0,  299,    2, 0x0a /* Public */,
      35,    1,  300,    2, 0x0a /* Public */,
      36,    1,  303,    2, 0x0a /* Public */,
      37,    0,  306,    2, 0x0a /* Public */,
      38,    0,  307,    2, 0x0a /* Public */,
      39,    1,  308,    2, 0x0a /* Public */,
      40,    0,  311,    2, 0x0a /* Public */,
      41,    0,  312,    2, 0x0a /* Public */,
      42,    0,  313,    2, 0x0a /* Public */,
      43,    0,  314,    2, 0x0a /* Public */,
      44,    1,  315,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QStringList,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::UInt,    2,
    QMetaType::Void, QMetaType::Bool, QMetaType::ULongLong,    2,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::QRectF,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QStringList,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,   25,
    QMetaType::Void, QMetaType::QString,   25,
    QMetaType::Void, QMetaType::UInt,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   32,
    QMetaType::Void, QMetaType::Bool, QMetaType::ULongLong,    2,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QRectF,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,

       0        // eod
};

void UIManager::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        UIManager *_t = static_cast<UIManager *>(_o);
        switch (_id) {
        case 0: _t->Sig_FrontEndCombine((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        case 1: _t->Sig_FrontEndCMD((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->Sig_SerialPort((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->Sig_SerialConnect((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->Sig_Print(); break;
        case 5: _t->Sig_Stop(); break;
        case 6: _t->Sig_Cancle(); break;
        case 7: _t->Sig_FinishPersent((*reinterpret_cast< uint(*)>(_a[1]))); break;
        case 8: _t->Sig_ProcessBar((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< quint64(*)>(_a[2]))); break;
        case 9: _t->Sig_Recover(); break;
        case 10: _t->Sig_ConnectFaile((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: _t->Sig_ConnectFirstFaile((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 12: _t->Sig_Bounding((*reinterpret_cast< QRectF(*)>(_a[1]))); break;
        case 13: _t->slotAA((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 14: _t->slotAB((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 15: _t->slotAC((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 16: _t->slotAD((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 17: _t->slotAE((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 18: _t->slotAF((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 19: _t->slotMWin((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 20: _t->slotCombinrFile((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        case 21: _t->slotToLaser((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 22: _t->slotSerialPort((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 23: _t->slotSerialConnect((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 24: _t->slotFinishPersent((*reinterpret_cast< uint(*)>(_a[1]))); break;
        case 25: _t->slotPrint(); break;
        case 26: _t->slotStop(); break;
        case 27: _t->slotCancle(); break;
        case 28: _t->slotServerLoad((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 29: _t->slotProcessBar((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< quint64(*)>(_a[2]))); break;
        case 30: _t->slotRecover(); break;
        case 31: _t->slotConnectFaile((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 32: _t->slotConnectFirstFaile((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 33: _t->slotShowLoad(); break;
        case 34: _t->slotLoadIn(); break;
        case 35: _t->slotBounding((*reinterpret_cast< QRectF(*)>(_a[1]))); break;
        case 36: _t->slotAGSuccessful(); break;
        case 37: _t->slotAGFailed(); break;
        case 38: _t->slotAHNextStep(); break;
        case 39: _t->slotLoadNext(); break;
        case 40: _t->slotEndStopState((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (UIManager::*_t)(QStringList );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&UIManager::Sig_FrontEndCombine)) {
                *result = 0;
            }
        }
        {
            typedef void (UIManager::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&UIManager::Sig_FrontEndCMD)) {
                *result = 1;
            }
        }
        {
            typedef void (UIManager::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&UIManager::Sig_SerialPort)) {
                *result = 2;
            }
        }
        {
            typedef void (UIManager::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&UIManager::Sig_SerialConnect)) {
                *result = 3;
            }
        }
        {
            typedef void (UIManager::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&UIManager::Sig_Print)) {
                *result = 4;
            }
        }
        {
            typedef void (UIManager::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&UIManager::Sig_Stop)) {
                *result = 5;
            }
        }
        {
            typedef void (UIManager::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&UIManager::Sig_Cancle)) {
                *result = 6;
            }
        }
        {
            typedef void (UIManager::*_t)(unsigned int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&UIManager::Sig_FinishPersent)) {
                *result = 7;
            }
        }
        {
            typedef void (UIManager::*_t)(bool , quint64 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&UIManager::Sig_ProcessBar)) {
                *result = 8;
            }
        }
        {
            typedef void (UIManager::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&UIManager::Sig_Recover)) {
                *result = 9;
            }
        }
        {
            typedef void (UIManager::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&UIManager::Sig_ConnectFaile)) {
                *result = 10;
            }
        }
        {
            typedef void (UIManager::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&UIManager::Sig_ConnectFirstFaile)) {
                *result = 11;
            }
        }
        {
            typedef void (UIManager::*_t)(QRectF );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&UIManager::Sig_Bounding)) {
                *result = 12;
            }
        }
    }
}

const QMetaObject UIManager::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_UIManager.data,
      qt_meta_data_UIManager,  qt_static_metacall, 0, 0}
};


const QMetaObject *UIManager::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *UIManager::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_UIManager.stringdata))
        return static_cast<void*>(const_cast< UIManager*>(this));
    return QObject::qt_metacast(_clname);
}

int UIManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 41)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 41;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 41)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 41;
    }
    return _id;
}

// SIGNAL 0
void UIManager::Sig_FrontEndCombine(QStringList _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void UIManager::Sig_FrontEndCMD(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void UIManager::Sig_SerialPort(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void UIManager::Sig_SerialConnect(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void UIManager::Sig_Print()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}

// SIGNAL 5
void UIManager::Sig_Stop()
{
    QMetaObject::activate(this, &staticMetaObject, 5, 0);
}

// SIGNAL 6
void UIManager::Sig_Cancle()
{
    QMetaObject::activate(this, &staticMetaObject, 6, 0);
}

// SIGNAL 7
void UIManager::Sig_FinishPersent(unsigned int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void UIManager::Sig_ProcessBar(bool _t1, quint64 _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void UIManager::Sig_Recover()
{
    QMetaObject::activate(this, &staticMetaObject, 9, 0);
}

// SIGNAL 10
void UIManager::Sig_ConnectFaile(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void UIManager::Sig_ConnectFirstFaile(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void UIManager::Sig_Bounding(QRectF _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}
QT_END_MOC_NAMESPACE
