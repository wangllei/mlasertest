/****************************************************************************
** Meta object code from reading C++ file 'bc_expertform.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "E:/mlaser/mLaser1.0/MLaser/UICompment/bc_expertform.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'bc_expertform.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_BC_ExpertForm_t {
    QByteArrayData data[48];
    char stringdata[1080];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_BC_ExpertForm_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_BC_ExpertForm_t qt_meta_stringdata_BC_ExpertForm = {
    {
QT_MOC_LITERAL(0, 0, 13),
QT_MOC_LITERAL(1, 14, 11),
QT_MOC_LITERAL(2, 26, 0),
QT_MOC_LITERAL(3, 27, 9),
QT_MOC_LITERAL(4, 37, 6),
QT_MOC_LITERAL(5, 44, 9),
QT_MOC_LITERAL(6, 54, 8),
QT_MOC_LITERAL(7, 63, 10),
QT_MOC_LITERAL(8, 74, 11),
QT_MOC_LITERAL(9, 86, 11),
QT_MOC_LITERAL(10, 98, 18),
QT_MOC_LITERAL(11, 117, 11),
QT_MOC_LITERAL(12, 129, 1),
QT_MOC_LITERAL(13, 131, 27),
QT_MOC_LITERAL(14, 159, 5),
QT_MOC_LITERAL(15, 165, 20),
QT_MOC_LITERAL(16, 186, 19),
QT_MOC_LITERAL(17, 206, 23),
QT_MOC_LITERAL(18, 230, 19),
QT_MOC_LITERAL(19, 250, 18),
QT_MOC_LITERAL(20, 269, 21),
QT_MOC_LITERAL(21, 291, 21),
QT_MOC_LITERAL(22, 313, 36),
QT_MOC_LITERAL(23, 350, 4),
QT_MOC_LITERAL(24, 355, 31),
QT_MOC_LITERAL(25, 387, 30),
QT_MOC_LITERAL(26, 418, 33),
QT_MOC_LITERAL(27, 452, 35),
QT_MOC_LITERAL(28, 488, 5),
QT_MOC_LITERAL(29, 494, 34),
QT_MOC_LITERAL(30, 529, 34),
QT_MOC_LITERAL(31, 564, 33),
QT_MOC_LITERAL(32, 598, 35),
QT_MOC_LITERAL(33, 634, 25),
QT_MOC_LITERAL(34, 660, 24),
QT_MOC_LITERAL(35, 685, 38),
QT_MOC_LITERAL(36, 724, 19),
QT_MOC_LITERAL(37, 744, 17),
QT_MOC_LITERAL(38, 762, 17),
QT_MOC_LITERAL(39, 780, 33),
QT_MOC_LITERAL(40, 814, 32),
QT_MOC_LITERAL(41, 847, 35),
QT_MOC_LITERAL(42, 883, 43),
QT_MOC_LITERAL(43, 927, 4),
QT_MOC_LITERAL(44, 932, 36),
QT_MOC_LITERAL(45, 969, 36),
QT_MOC_LITERAL(46, 1006, 35),
QT_MOC_LITERAL(47, 1042, 37)
    },
    "BC_ExpertForm\0Sig_Cutting\0\0Sig_Carve\0"
    "Sig_BD\0Sig_Print\0Sig_Stop\0Sig_Cancle\0"
    "Sig_Preview\0Sig_LaserOn\0slotUpdateParmeter\0"
    "setLanguage\0l\0on_toggleLaser_valueChanged\0"
    "value\0on_btnSlicer_clicked\0"
    "on_btnCarve_clicked\0on_btnOpenPanel_clicked\0"
    "on_btnStart_clicked\0on_btnStop_clicked\0"
    "on_btnPreview_clicked\0on_btnSetHome_clicked\0"
    "on_comboMaterial_currentIndexChanged\0"
    "arg1\0on_lineEditRepeat_returnPressed\0"
    "on_lineEditPower_returnPressed\0"
    "on_lineEditPixSpeed_returnPressed\0"
    "on_lineEditSpaceSpeed_returnPressed\0"
    "index\0on_lineEditCarvSpeed_returnPressed\0"
    "on_lineEditCarvPiwer_returnPressed\0"
    "on_lineEditCarvTime_returnPressed\0"
    "on_lineEditCarvPixcel_returnPressed\0"
    "on_btnPointLaser_released\0"
    "on_btnPointLaser_pressed\0"
    "on_comboBoxPicType_currentIndexChanged\0"
    "on_btnPower_clicked\0on_btnOK1_clicked\0"
    "on_btnOK2_clicked\0on_lineEditRepeat_editingFinished\0"
    "on_lineEditPower_editingFinished\0"
    "on_lineEditPixSpeed_editingFinished\0"
    "on_lineEditSpaceSpeed_cursorPositionChanged\0"
    "arg2\0on_lineEditCarvSpeed_editingFinished\0"
    "on_lineEditCarvPiwer_editingFinished\0"
    "on_lineEditCarvTime_editingFinished\0"
    "on_lineEditCarvPixcel_editingFinished"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_BC_ExpertForm[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      42,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       8,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  224,    2, 0x06 /* Public */,
       3,    0,  225,    2, 0x06 /* Public */,
       4,    1,  226,    2, 0x06 /* Public */,
       5,    0,  229,    2, 0x06 /* Public */,
       6,    0,  230,    2, 0x06 /* Public */,
       7,    0,  231,    2, 0x06 /* Public */,
       8,    0,  232,    2, 0x06 /* Public */,
       9,    1,  233,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      10,    0,  236,    2, 0x0a /* Public */,
      11,    1,  237,    2, 0x0a /* Public */,
      13,    1,  240,    2, 0x08 /* Private */,
      15,    0,  243,    2, 0x08 /* Private */,
      16,    0,  244,    2, 0x08 /* Private */,
      17,    0,  245,    2, 0x08 /* Private */,
      18,    0,  246,    2, 0x08 /* Private */,
      19,    0,  247,    2, 0x08 /* Private */,
      20,    0,  248,    2, 0x08 /* Private */,
      21,    0,  249,    2, 0x08 /* Private */,
      22,    1,  250,    2, 0x08 /* Private */,
      24,    0,  253,    2, 0x08 /* Private */,
      25,    0,  254,    2, 0x08 /* Private */,
      26,    0,  255,    2, 0x08 /* Private */,
      27,    0,  256,    2, 0x08 /* Private */,
      22,    1,  257,    2, 0x08 /* Private */,
      29,    0,  260,    2, 0x08 /* Private */,
      30,    0,  261,    2, 0x08 /* Private */,
      31,    0,  262,    2, 0x08 /* Private */,
      32,    0,  263,    2, 0x08 /* Private */,
      33,    0,  264,    2, 0x08 /* Private */,
      34,    0,  265,    2, 0x08 /* Private */,
      35,    1,  266,    2, 0x08 /* Private */,
      36,    0,  269,    2, 0x08 /* Private */,
      37,    0,  270,    2, 0x08 /* Private */,
      38,    0,  271,    2, 0x08 /* Private */,
      39,    0,  272,    2, 0x08 /* Private */,
      40,    0,  273,    2, 0x08 /* Private */,
      41,    0,  274,    2, 0x08 /* Private */,
      42,    2,  275,    2, 0x08 /* Private */,
      44,    0,  280,    2, 0x08 /* Private */,
      45,    0,  281,    2, 0x08 /* Private */,
      46,    0,  282,    2, 0x08 /* Private */,
      47,    0,  283,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   12,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   23,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   28,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   28,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   23,   43,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void BC_ExpertForm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        BC_ExpertForm *_t = static_cast<BC_ExpertForm *>(_o);
        switch (_id) {
        case 0: _t->Sig_Cutting(); break;
        case 1: _t->Sig_Carve(); break;
        case 2: _t->Sig_BD((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->Sig_Print(); break;
        case 4: _t->Sig_Stop(); break;
        case 5: _t->Sig_Cancle(); break;
        case 6: _t->Sig_Preview(); break;
        case 7: _t->Sig_LaserOn((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 8: _t->slotUpdateParmeter(); break;
        case 9: _t->setLanguage((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->on_toggleLaser_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->on_btnSlicer_clicked(); break;
        case 12: _t->on_btnCarve_clicked(); break;
        case 13: _t->on_btnOpenPanel_clicked(); break;
        case 14: _t->on_btnStart_clicked(); break;
        case 15: _t->on_btnStop_clicked(); break;
        case 16: _t->on_btnPreview_clicked(); break;
        case 17: _t->on_btnSetHome_clicked(); break;
        case 18: _t->on_comboMaterial_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 19: _t->on_lineEditRepeat_returnPressed(); break;
        case 20: _t->on_lineEditPower_returnPressed(); break;
        case 21: _t->on_lineEditPixSpeed_returnPressed(); break;
        case 22: _t->on_lineEditSpaceSpeed_returnPressed(); break;
        case 23: _t->on_comboMaterial_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 24: _t->on_lineEditCarvSpeed_returnPressed(); break;
        case 25: _t->on_lineEditCarvPiwer_returnPressed(); break;
        case 26: _t->on_lineEditCarvTime_returnPressed(); break;
        case 27: _t->on_lineEditCarvPixcel_returnPressed(); break;
        case 28: _t->on_btnPointLaser_released(); break;
        case 29: _t->on_btnPointLaser_pressed(); break;
        case 30: _t->on_comboBoxPicType_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 31: _t->on_btnPower_clicked(); break;
        case 32: _t->on_btnOK1_clicked(); break;
        case 33: _t->on_btnOK2_clicked(); break;
        case 34: _t->on_lineEditRepeat_editingFinished(); break;
        case 35: _t->on_lineEditPower_editingFinished(); break;
        case 36: _t->on_lineEditPixSpeed_editingFinished(); break;
        case 37: _t->on_lineEditSpaceSpeed_cursorPositionChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 38: _t->on_lineEditCarvSpeed_editingFinished(); break;
        case 39: _t->on_lineEditCarvPiwer_editingFinished(); break;
        case 40: _t->on_lineEditCarvTime_editingFinished(); break;
        case 41: _t->on_lineEditCarvPixcel_editingFinished(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (BC_ExpertForm::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&BC_ExpertForm::Sig_Cutting)) {
                *result = 0;
            }
        }
        {
            typedef void (BC_ExpertForm::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&BC_ExpertForm::Sig_Carve)) {
                *result = 1;
            }
        }
        {
            typedef void (BC_ExpertForm::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&BC_ExpertForm::Sig_BD)) {
                *result = 2;
            }
        }
        {
            typedef void (BC_ExpertForm::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&BC_ExpertForm::Sig_Print)) {
                *result = 3;
            }
        }
        {
            typedef void (BC_ExpertForm::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&BC_ExpertForm::Sig_Stop)) {
                *result = 4;
            }
        }
        {
            typedef void (BC_ExpertForm::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&BC_ExpertForm::Sig_Cancle)) {
                *result = 5;
            }
        }
        {
            typedef void (BC_ExpertForm::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&BC_ExpertForm::Sig_Preview)) {
                *result = 6;
            }
        }
        {
            typedef void (BC_ExpertForm::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&BC_ExpertForm::Sig_LaserOn)) {
                *result = 7;
            }
        }
    }
}

const QMetaObject BC_ExpertForm::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_BC_ExpertForm.data,
      qt_meta_data_BC_ExpertForm,  qt_static_metacall, 0, 0}
};


const QMetaObject *BC_ExpertForm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BC_ExpertForm::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_BC_ExpertForm.stringdata))
        return static_cast<void*>(const_cast< BC_ExpertForm*>(this));
    return QWidget::qt_metacast(_clname);
}

int BC_ExpertForm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 42)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 42;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 42)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 42;
    }
    return _id;
}

// SIGNAL 0
void BC_ExpertForm::Sig_Cutting()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void BC_ExpertForm::Sig_Carve()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void BC_ExpertForm::Sig_BD(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void BC_ExpertForm::Sig_Print()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}

// SIGNAL 4
void BC_ExpertForm::Sig_Stop()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}

// SIGNAL 5
void BC_ExpertForm::Sig_Cancle()
{
    QMetaObject::activate(this, &staticMetaObject, 5, 0);
}

// SIGNAL 6
void BC_ExpertForm::Sig_Preview()
{
    QMetaObject::activate(this, &staticMetaObject, 6, 0);
}

// SIGNAL 7
void BC_ExpertForm::Sig_LaserOn(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}
QT_END_MOC_NAMESPACE
