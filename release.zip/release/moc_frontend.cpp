/****************************************************************************
** Meta object code from reading C++ file 'frontend.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "E:/mlaser/mLaser1.0/MLaser/Communicate/serial/frontend.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QQueue>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'frontend.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_FrontEnd_t {
    QByteArrayData data[34];
    char stringdata[421];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_FrontEnd_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_FrontEnd_t qt_meta_stringdata_FrontEnd = {
    {
QT_MOC_LITERAL(0, 0, 8),
QT_MOC_LITERAL(1, 9, 13),
QT_MOC_LITERAL(2, 23, 0),
QT_MOC_LITERAL(3, 24, 10),
QT_MOC_LITERAL(4, 35, 15),
QT_MOC_LITERAL(5, 51, 13),
QT_MOC_LITERAL(6, 65, 14),
QT_MOC_LITERAL(7, 80, 17),
QT_MOC_LITERAL(8, 98, 14),
QT_MOC_LITERAL(9, 113, 16),
QT_MOC_LITERAL(10, 130, 1),
QT_MOC_LITERAL(11, 132, 21),
QT_MOC_LITERAL(12, 154, 16),
QT_MOC_LITERAL(13, 171, 9),
QT_MOC_LITERAL(14, 181, 8),
QT_MOC_LITERAL(15, 190, 9),
QT_MOC_LITERAL(16, 200, 10),
QT_MOC_LITERAL(17, 211, 16),
QT_MOC_LITERAL(18, 228, 11),
QT_MOC_LITERAL(19, 240, 11),
QT_MOC_LITERAL(20, 252, 3),
QT_MOC_LITERAL(21, 256, 11),
QT_MOC_LITERAL(22, 268, 11),
QT_MOC_LITERAL(23, 280, 15),
QT_MOC_LITERAL(24, 296, 1),
QT_MOC_LITERAL(25, 298, 10),
QT_MOC_LITERAL(26, 309, 13),
QT_MOC_LITERAL(27, 323, 11),
QT_MOC_LITERAL(28, 335, 16),
QT_MOC_LITERAL(29, 352, 15),
QT_MOC_LITERAL(30, 368, 15),
QT_MOC_LITERAL(31, 384, 1),
QT_MOC_LITERAL(32, 386, 17),
QT_MOC_LITERAL(33, 404, 16)
    },
    "FrontEnd\0Sig_ToArduino\0\0Sig_UiShow\0"
    "Sig_SceneChange\0Sig_Connected\0"
    "Sig_Disconnect\0Sig_FinishPersent\0"
    "Sig_ProcessBar\0Sig_ConnectFaile\0b\0"
    "Sig_ConnectFirstFaile\0Sig_EndStopState\0"
    "slotPrint\0slotStop\0slotRecov\0slotCancle\0"
    "slotDrawBounding\0addToSender\0readArduino\0"
    "cmd\0genBounding\0setBounding\0QQueue<QString>\0"
    "a\0bounddraws\0resetBounding\0slotUIWrite\0"
    "serialDisconnect\0slotCombineFile\0"
    "slotConnectPort\0m\0slotSerialConnect\0"
    "slotConnectFaile"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_FrontEnd[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      26,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      10,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  144,    2, 0x06 /* Public */,
       3,    1,  147,    2, 0x06 /* Public */,
       4,    0,  150,    2, 0x06 /* Public */,
       5,    0,  151,    2, 0x06 /* Public */,
       6,    0,  152,    2, 0x06 /* Public */,
       7,    1,  153,    2, 0x06 /* Public */,
       8,    2,  156,    2, 0x06 /* Public */,
       9,    1,  161,    2, 0x06 /* Public */,
      11,    1,  164,    2, 0x06 /* Public */,
      12,    1,  167,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      13,    0,  170,    2, 0x0a /* Public */,
      14,    0,  171,    2, 0x0a /* Public */,
      15,    0,  172,    2, 0x0a /* Public */,
      16,    0,  173,    2, 0x0a /* Public */,
      17,    1,  174,    2, 0x0a /* Public */,
      18,    0,  177,    2, 0x0a /* Public */,
      19,    1,  178,    2, 0x0a /* Public */,
      21,    1,  181,    2, 0x0a /* Public */,
      22,    2,  184,    2, 0x0a /* Public */,
      26,    0,  189,    2, 0x0a /* Public */,
      27,    1,  190,    2, 0x0a /* Public */,
      28,    0,  193,    2, 0x0a /* Public */,
      29,    1,  194,    2, 0x0a /* Public */,
      30,    1,  197,    2, 0x0a /* Public */,
      32,    1,  200,    2, 0x0a /* Public */,
      33,    1,  203,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::UInt,    2,
    QMetaType::Void, QMetaType::Bool, QMetaType::ULongLong,    2,    2,
    QMetaType::Void, QMetaType::Bool,   10,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Int,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QRectF,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   20,
    QMetaType::Void, QMetaType::QRectF,    2,
    QMetaType::Void, 0x80000000 | 23, QMetaType::Bool,   24,   25,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QStringList,    2,
    QMetaType::Void, QMetaType::QString,   31,
    QMetaType::Void, QMetaType::QString,   31,
    QMetaType::Void, QMetaType::Bool,    2,

       0        // eod
};

void FrontEnd::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        FrontEnd *_t = static_cast<FrontEnd *>(_o);
        switch (_id) {
        case 0: _t->Sig_ToArduino((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->Sig_UiShow((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->Sig_SceneChange(); break;
        case 3: _t->Sig_Connected(); break;
        case 4: _t->Sig_Disconnect(); break;
        case 5: _t->Sig_FinishPersent((*reinterpret_cast< uint(*)>(_a[1]))); break;
        case 6: _t->Sig_ProcessBar((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< quint64(*)>(_a[2]))); break;
        case 7: _t->Sig_ConnectFaile((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->Sig_ConnectFirstFaile((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 9: _t->Sig_EndStopState((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->slotPrint(); break;
        case 11: _t->slotStop(); break;
        case 12: _t->slotRecov(); break;
        case 13: _t->slotCancle(); break;
        case 14: _t->slotDrawBounding((*reinterpret_cast< QRectF(*)>(_a[1]))); break;
        case 15: _t->addToSender(); break;
        case 16: _t->readArduino((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 17: _t->genBounding((*reinterpret_cast< QRectF(*)>(_a[1]))); break;
        case 18: _t->setBounding((*reinterpret_cast< QQueue<QString>(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 19: _t->resetBounding(); break;
        case 20: _t->slotUIWrite((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 21: _t->serialDisconnect(); break;
        case 22: _t->slotCombineFile((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        case 23: _t->slotConnectPort((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 24: _t->slotSerialConnect((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 25: _t->slotConnectFaile((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 18:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QQueue<QString> >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (FrontEnd::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&FrontEnd::Sig_ToArduino)) {
                *result = 0;
            }
        }
        {
            typedef void (FrontEnd::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&FrontEnd::Sig_UiShow)) {
                *result = 1;
            }
        }
        {
            typedef void (FrontEnd::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&FrontEnd::Sig_SceneChange)) {
                *result = 2;
            }
        }
        {
            typedef void (FrontEnd::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&FrontEnd::Sig_Connected)) {
                *result = 3;
            }
        }
        {
            typedef void (FrontEnd::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&FrontEnd::Sig_Disconnect)) {
                *result = 4;
            }
        }
        {
            typedef void (FrontEnd::*_t)(unsigned int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&FrontEnd::Sig_FinishPersent)) {
                *result = 5;
            }
        }
        {
            typedef void (FrontEnd::*_t)(bool , quint64 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&FrontEnd::Sig_ProcessBar)) {
                *result = 6;
            }
        }
        {
            typedef void (FrontEnd::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&FrontEnd::Sig_ConnectFaile)) {
                *result = 7;
            }
        }
        {
            typedef void (FrontEnd::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&FrontEnd::Sig_ConnectFirstFaile)) {
                *result = 8;
            }
        }
        {
            typedef void (FrontEnd::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&FrontEnd::Sig_EndStopState)) {
                *result = 9;
            }
        }
    }
}

const QMetaObject FrontEnd::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_FrontEnd.data,
      qt_meta_data_FrontEnd,  qt_static_metacall, 0, 0}
};


const QMetaObject *FrontEnd::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FrontEnd::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_FrontEnd.stringdata))
        return static_cast<void*>(const_cast< FrontEnd*>(this));
    return QThread::qt_metacast(_clname);
}

int FrontEnd::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 26)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 26;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 26)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 26;
    }
    return _id;
}

// SIGNAL 0
void FrontEnd::Sig_ToArduino(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void FrontEnd::Sig_UiShow(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void FrontEnd::Sig_SceneChange()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void FrontEnd::Sig_Connected()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}

// SIGNAL 4
void FrontEnd::Sig_Disconnect()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}

// SIGNAL 5
void FrontEnd::Sig_FinishPersent(unsigned int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void FrontEnd::Sig_ProcessBar(bool _t1, quint64 _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void FrontEnd::Sig_ConnectFaile(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void FrontEnd::Sig_ConnectFirstFaile(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void FrontEnd::Sig_EndStopState(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}
QT_END_MOC_NAMESPACE
