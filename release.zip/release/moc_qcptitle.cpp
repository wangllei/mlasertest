/****************************************************************************
** Meta object code from reading C++ file 'qcptitle.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "E:/mlaser/mLaser1.0/MLaser/UICompment/qcptitle.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qcptitle.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_QCPTitle_t {
    QByteArrayData data[60];
    char stringdata[795];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPTitle_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPTitle_t qt_meta_stringdata_QCPTitle = {
    {
QT_MOC_LITERAL(0, 0, 8),
QT_MOC_LITERAL(1, 9, 8),
QT_MOC_LITERAL(2, 18, 0),
QT_MOC_LITERAL(3, 19, 11),
QT_MOC_LITERAL(4, 31, 12),
QT_MOC_LITERAL(5, 44, 11),
QT_MOC_LITERAL(6, 56, 15),
QT_MOC_LITERAL(7, 72, 10),
QT_MOC_LITERAL(8, 83, 17),
QT_MOC_LITERAL(9, 101, 11),
QT_MOC_LITERAL(10, 113, 14),
QT_MOC_LITERAL(11, 128, 9),
QT_MOC_LITERAL(12, 138, 8),
QT_MOC_LITERAL(13, 147, 11),
QT_MOC_LITERAL(14, 159, 10),
QT_MOC_LITERAL(15, 170, 14),
QT_MOC_LITERAL(16, 185, 12),
QT_MOC_LITERAL(17, 198, 16),
QT_MOC_LITERAL(18, 215, 15),
QT_MOC_LITERAL(19, 231, 6),
QT_MOC_LITERAL(20, 238, 6),
QT_MOC_LITERAL(21, 245, 6),
QT_MOC_LITERAL(22, 252, 6),
QT_MOC_LITERAL(23, 259, 10),
QT_MOC_LITERAL(24, 270, 11),
QT_MOC_LITERAL(25, 282, 12),
QT_MOC_LITERAL(26, 295, 12),
QT_MOC_LITERAL(27, 308, 14),
QT_MOC_LITERAL(28, 323, 12),
QT_MOC_LITERAL(29, 336, 11),
QT_MOC_LITERAL(30, 348, 8),
QT_MOC_LITERAL(31, 357, 10),
QT_MOC_LITERAL(32, 368, 11),
QT_MOC_LITERAL(33, 380, 9),
QT_MOC_LITERAL(34, 390, 17),
QT_MOC_LITERAL(35, 408, 11),
QT_MOC_LITERAL(36, 420, 8),
QT_MOC_LITERAL(37, 429, 9),
QT_MOC_LITERAL(38, 439, 10),
QT_MOC_LITERAL(39, 450, 17),
QT_MOC_LITERAL(40, 468, 11),
QT_MOC_LITERAL(41, 480, 11),
QT_MOC_LITERAL(42, 492, 14),
QT_MOC_LITERAL(43, 507, 13),
QT_MOC_LITERAL(44, 521, 16),
QT_MOC_LITERAL(45, 538, 16),
QT_MOC_LITERAL(46, 555, 1),
QT_MOC_LITERAL(47, 557, 11),
QT_MOC_LITERAL(48, 569, 11),
QT_MOC_LITERAL(49, 581, 15),
QT_MOC_LITERAL(50, 597, 18),
QT_MOC_LITERAL(51, 616, 23),
QT_MOC_LITERAL(52, 640, 21),
QT_MOC_LITERAL(53, 662, 18),
QT_MOC_LITERAL(54, 681, 19),
QT_MOC_LITERAL(55, 701, 27),
QT_MOC_LITERAL(56, 729, 4),
QT_MOC_LITERAL(57, 734, 20),
QT_MOC_LITERAL(58, 755, 20),
QT_MOC_LITERAL(59, 776, 18)
    },
    "QCPTitle\0Sig_MWin\0\0Sig_BD_Open\0"
    "Sig_MAddFont\0Sig_BD_Rect\0Sig_ProcessItem\0"
    "Sig_SaveAs\0Sig_BDCombineFile\0Sig_ToLaser\0"
    "Sig_SerialPort\0Sig_Print\0Sig_Stop\0"
    "Sig_Recover\0Sig_Cancle\0Sig_ProcessBar\0"
    "Sig_Bounding\0Sig_ReadParmeter\0"
    "Sig_Setlanguage\0slotBA\0slotBB\0slotBC\0"
    "slotBD\0slotExpert\0slotCoustom\0"
    "slotZhAction\0slotEnAction\0slotInchAction\0"
    "slotMMAction\0slotAddFont\0slotSave\0"
    "slotSaveAs\0slotCutting\0slotCarve\0"
    "slotBDCombineFile\0slotToLaser\0slotStop\0"
    "slotPrint\0slotCancle\0slotFinishPersent\0"
    "slotLaserOn\0slotPreview\0slotProcessBar\0"
    "slotGcodeMode\0slotConnectFaile\0"
    "slotSerialAction\0t\0slotHexLoad\0"
    "slotShowPos\0slotFirmSetting\0"
    "on_btnText_clicked\0on_btnOpenPanel_clicked\0"
    "on_btnSetHome_clicked\0on_btnOpen_clicked\0"
    "on_btnDelet_clicked\0on_comboBoxSerial_activated\0"
    "arg1\0on_btnSerial_clicked\0"
    "on_btnQrcode_clicked\0on_btnSave_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPTitle[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      56,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      17,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  294,    2, 0x06 /* Public */,
       3,    1,  297,    2, 0x06 /* Public */,
       4,    1,  300,    2, 0x06 /* Public */,
       5,    1,  303,    2, 0x06 /* Public */,
       6,    0,  306,    2, 0x06 /* Public */,
       7,    1,  307,    2, 0x06 /* Public */,
       8,    1,  310,    2, 0x06 /* Public */,
       9,    1,  313,    2, 0x06 /* Public */,
      10,    1,  316,    2, 0x06 /* Public */,
      11,    0,  319,    2, 0x06 /* Public */,
      12,    0,  320,    2, 0x06 /* Public */,
      13,    0,  321,    2, 0x06 /* Public */,
      14,    0,  322,    2, 0x06 /* Public */,
      15,    2,  323,    2, 0x06 /* Public */,
      16,    1,  328,    2, 0x06 /* Public */,
      17,    0,  331,    2, 0x06 /* Public */,
      18,    1,  332,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      19,    1,  335,    2, 0x0a /* Public */,
      20,    1,  338,    2, 0x0a /* Public */,
      21,    1,  341,    2, 0x0a /* Public */,
      22,    1,  344,    2, 0x0a /* Public */,
      23,    0,  347,    2, 0x0a /* Public */,
      24,    0,  348,    2, 0x0a /* Public */,
      25,    0,  349,    2, 0x0a /* Public */,
      26,    0,  350,    2, 0x0a /* Public */,
      27,    0,  351,    2, 0x0a /* Public */,
      28,    0,  352,    2, 0x0a /* Public */,
      29,    1,  353,    2, 0x0a /* Public */,
      30,    0,  356,    2, 0x0a /* Public */,
      31,    0,  357,    2, 0x0a /* Public */,
      32,    0,  358,    2, 0x0a /* Public */,
      33,    0,  359,    2, 0x0a /* Public */,
      34,    1,  360,    2, 0x0a /* Public */,
      35,    1,  363,    2, 0x0a /* Public */,
      36,    0,  366,    2, 0x0a /* Public */,
      37,    0,  367,    2, 0x0a /* Public */,
      38,    0,  368,    2, 0x0a /* Public */,
      39,    1,  369,    2, 0x0a /* Public */,
      40,    1,  372,    2, 0x0a /* Public */,
      41,    0,  375,    2, 0x0a /* Public */,
      42,    2,  376,    2, 0x0a /* Public */,
      43,    0,  381,    2, 0x0a /* Public */,
      44,    1,  382,    2, 0x0a /* Public */,
      45,    1,  385,    2, 0x0a /* Public */,
      47,    0,  388,    2, 0x0a /* Public */,
      48,    1,  389,    2, 0x0a /* Public */,
      49,    0,  392,    2, 0x0a /* Public */,
      50,    0,  393,    2, 0x08 /* Private */,
      51,    0,  394,    2, 0x08 /* Private */,
      52,    0,  395,    2, 0x08 /* Private */,
      53,    0,  396,    2, 0x08 /* Private */,
      54,    0,  397,    2, 0x08 /* Private */,
      55,    1,  398,    2, 0x08 /* Private */,
      57,    0,  401,    2, 0x08 /* Private */,
      58,    0,  402,    2, 0x08 /* Private */,
      59,    0,  403,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QRect,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QStringList,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool, QMetaType::UInt,    2,    2,
    QMetaType::Void, QMetaType::QRectF,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QStringList,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::UInt,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool, QMetaType::ULongLong,    2,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,   46,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QRectF,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   56,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void QCPTitle::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPTitle *_t = static_cast<QCPTitle *>(_o);
        switch (_id) {
        case 0: _t->Sig_MWin((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->Sig_BD_Open((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->Sig_MAddFont((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->Sig_BD_Rect((*reinterpret_cast< QRect(*)>(_a[1]))); break;
        case 4: _t->Sig_ProcessItem(); break;
        case 5: _t->Sig_SaveAs((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 6: _t->Sig_BDCombineFile((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        case 7: _t->Sig_ToLaser((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 8: _t->Sig_SerialPort((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 9: _t->Sig_Print(); break;
        case 10: _t->Sig_Stop(); break;
        case 11: _t->Sig_Recover(); break;
        case 12: _t->Sig_Cancle(); break;
        case 13: _t->Sig_ProcessBar((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< uint(*)>(_a[2]))); break;
        case 14: _t->Sig_Bounding((*reinterpret_cast< QRectF(*)>(_a[1]))); break;
        case 15: _t->Sig_ReadParmeter(); break;
        case 16: _t->Sig_Setlanguage((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 17: _t->slotBA((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 18: _t->slotBB((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 19: _t->slotBC((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 20: _t->slotBD((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 21: _t->slotExpert(); break;
        case 22: _t->slotCoustom(); break;
        case 23: _t->slotZhAction(); break;
        case 24: _t->slotEnAction(); break;
        case 25: _t->slotInchAction(); break;
        case 26: _t->slotMMAction(); break;
        case 27: _t->slotAddFont((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 28: _t->slotSave(); break;
        case 29: _t->slotSaveAs(); break;
        case 30: _t->slotCutting(); break;
        case 31: _t->slotCarve(); break;
        case 32: _t->slotBDCombineFile((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        case 33: _t->slotToLaser((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 34: _t->slotStop(); break;
        case 35: _t->slotPrint(); break;
        case 36: _t->slotCancle(); break;
        case 37: _t->slotFinishPersent((*reinterpret_cast< uint(*)>(_a[1]))); break;
        case 38: _t->slotLaserOn((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 39: _t->slotPreview(); break;
        case 40: _t->slotProcessBar((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< quint64(*)>(_a[2]))); break;
        case 41: _t->slotGcodeMode(); break;
        case 42: _t->slotConnectFaile((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 43: _t->slotSerialAction((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 44: _t->slotHexLoad(); break;
        case 45: _t->slotShowPos((*reinterpret_cast< QRectF(*)>(_a[1]))); break;
        case 46: _t->slotFirmSetting(); break;
        case 47: _t->on_btnText_clicked(); break;
        case 48: _t->on_btnOpenPanel_clicked(); break;
        case 49: _t->on_btnSetHome_clicked(); break;
        case 50: _t->on_btnOpen_clicked(); break;
        case 51: _t->on_btnDelet_clicked(); break;
        case 52: _t->on_comboBoxSerial_activated((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 53: _t->on_btnSerial_clicked(); break;
        case 54: _t->on_btnQrcode_clicked(); break;
        case 55: _t->on_btnSave_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPTitle::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_MWin)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPTitle::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_BD_Open)) {
                *result = 1;
            }
        }
        {
            typedef void (QCPTitle::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_MAddFont)) {
                *result = 2;
            }
        }
        {
            typedef void (QCPTitle::*_t)(QRect );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_BD_Rect)) {
                *result = 3;
            }
        }
        {
            typedef void (QCPTitle::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_ProcessItem)) {
                *result = 4;
            }
        }
        {
            typedef void (QCPTitle::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_SaveAs)) {
                *result = 5;
            }
        }
        {
            typedef void (QCPTitle::*_t)(QStringList );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_BDCombineFile)) {
                *result = 6;
            }
        }
        {
            typedef void (QCPTitle::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_ToLaser)) {
                *result = 7;
            }
        }
        {
            typedef void (QCPTitle::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_SerialPort)) {
                *result = 8;
            }
        }
        {
            typedef void (QCPTitle::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_Print)) {
                *result = 9;
            }
        }
        {
            typedef void (QCPTitle::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_Stop)) {
                *result = 10;
            }
        }
        {
            typedef void (QCPTitle::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_Recover)) {
                *result = 11;
            }
        }
        {
            typedef void (QCPTitle::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_Cancle)) {
                *result = 12;
            }
        }
        {
            typedef void (QCPTitle::*_t)(bool , unsigned int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_ProcessBar)) {
                *result = 13;
            }
        }
        {
            typedef void (QCPTitle::*_t)(QRectF );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_Bounding)) {
                *result = 14;
            }
        }
        {
            typedef void (QCPTitle::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_ReadParmeter)) {
                *result = 15;
            }
        }
        {
            typedef void (QCPTitle::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTitle::Sig_Setlanguage)) {
                *result = 16;
            }
        }
    }
}

const QMetaObject QCPTitle::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_QCPTitle.data,
      qt_meta_data_QCPTitle,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPTitle::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPTitle::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPTitle.stringdata))
        return static_cast<void*>(const_cast< QCPTitle*>(this));
    return QWidget::qt_metacast(_clname);
}

int QCPTitle::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 56)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 56;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 56)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 56;
    }
    return _id;
}

// SIGNAL 0
void QCPTitle::Sig_MWin(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPTitle::Sig_BD_Open(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPTitle::Sig_MAddFont(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void QCPTitle::Sig_BD_Rect(QRect _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void QCPTitle::Sig_ProcessItem()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}

// SIGNAL 5
void QCPTitle::Sig_SaveAs(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void QCPTitle::Sig_BDCombineFile(QStringList _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void QCPTitle::Sig_ToLaser(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void QCPTitle::Sig_SerialPort(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void QCPTitle::Sig_Print()
{
    QMetaObject::activate(this, &staticMetaObject, 9, 0);
}

// SIGNAL 10
void QCPTitle::Sig_Stop()
{
    QMetaObject::activate(this, &staticMetaObject, 10, 0);
}

// SIGNAL 11
void QCPTitle::Sig_Recover()
{
    QMetaObject::activate(this, &staticMetaObject, 11, 0);
}

// SIGNAL 12
void QCPTitle::Sig_Cancle()
{
    QMetaObject::activate(this, &staticMetaObject, 12, 0);
}

// SIGNAL 13
void QCPTitle::Sig_ProcessBar(bool _t1, unsigned int _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void QCPTitle::Sig_Bounding(QRectF _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}

// SIGNAL 15
void QCPTitle::Sig_ReadParmeter()
{
    QMetaObject::activate(this, &staticMetaObject, 15, 0);
}

// SIGNAL 16
void QCPTitle::Sig_Setlanguage(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 16, _a);
}
QT_END_MOC_NAMESPACE
