/****************************************************************************
** Meta object code from reading C++ file 'postionform.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "E:/mlaser/mLaser1.0/MLaser/UICompment/postionform.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'postionform.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_PostionForm_t {
    QByteArrayData data[7];
    char stringdata[127];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PostionForm_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PostionForm_t qt_meta_stringdata_PostionForm = {
    {
QT_MOC_LITERAL(0, 0, 11),
QT_MOC_LITERAL(1, 12, 6),
QT_MOC_LITERAL(2, 19, 0),
QT_MOC_LITERAL(3, 20, 21),
QT_MOC_LITERAL(4, 42, 28),
QT_MOC_LITERAL(5, 71, 26),
QT_MOC_LITERAL(6, 98, 28)
    },
    "PostionForm\0Sig_WH\0\0on_btnCertern_clicked\0"
    "on_lineEditH_editingFinished\0"
    "on_lineEditW_returnPressed\0"
    "on_lineEditW_editingFinished"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PostionForm[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   39,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    0,   42,    2, 0x08 /* Private */,
       4,    0,   43,    2, 0x08 /* Private */,
       5,    0,   44,    2, 0x08 /* Private */,
       6,    0,   45,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QPointF,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void PostionForm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        PostionForm *_t = static_cast<PostionForm *>(_o);
        switch (_id) {
        case 0: _t->Sig_WH((*reinterpret_cast< QPointF(*)>(_a[1]))); break;
        case 1: _t->on_btnCertern_clicked(); break;
        case 2: _t->on_lineEditH_editingFinished(); break;
        case 3: _t->on_lineEditW_returnPressed(); break;
        case 4: _t->on_lineEditW_editingFinished(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (PostionForm::*_t)(QPointF );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&PostionForm::Sig_WH)) {
                *result = 0;
            }
        }
    }
}

const QMetaObject PostionForm::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_PostionForm.data,
      qt_meta_data_PostionForm,  qt_static_metacall, 0, 0}
};


const QMetaObject *PostionForm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PostionForm::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_PostionForm.stringdata))
        return static_cast<void*>(const_cast< PostionForm*>(this));
    return QWidget::qt_metacast(_clname);
}

int PostionForm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void PostionForm::Sig_WH(QPointF _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
