/****************************************************************************
** Meta object code from reading C++ file 'svg2gcodep.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "E:/mlaser/mLaser1.0/MLaser/FileProcessor/svg2gcode/svg2gcodep.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'svg2gcodep.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Svg2GcodeP_t {
    QByteArrayData data[14];
    char stringdata[113];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Svg2GcodeP_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Svg2GcodeP_t qt_meta_stringdata_Svg2GcodeP = {
    {
QT_MOC_LITERAL(0, 0, 10),
QT_MOC_LITERAL(1, 11, 10),
QT_MOC_LITERAL(2, 22, 0),
QT_MOC_LITERAL(3, 23, 9),
QT_MOC_LITERAL(4, 33, 7),
QT_MOC_LITERAL(5, 41, 15),
QT_MOC_LITERAL(6, 57, 3),
QT_MOC_LITERAL(7, 61, 8),
QT_MOC_LITERAL(8, 70, 1),
QT_MOC_LITERAL(9, 72, 14),
QT_MOC_LITERAL(10, 87, 1),
QT_MOC_LITERAL(11, 89, 8),
QT_MOC_LITERAL(12, 98, 12),
QT_MOC_LITERAL(13, 111, 1)
    },
    "Svg2GcodeP\0SvgToGcode\0\0inputfile\0"
    "outfile\0SetGcoderHeader\0str\0SetLaser\0"
    "p\0SetgGcodeWidth\0w\0SetSpeed\0SetCloseLine\0"
    "a"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Svg2GcodeP[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    2,   44,    2, 0x0a /* Public */,
       5,    1,   49,    2, 0x0a /* Public */,
       7,    1,   52,    2, 0x0a /* Public */,
       9,    1,   55,    2, 0x0a /* Public */,
      11,    2,   58,    2, 0x0a /* Public */,
      12,    1,   63,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    3,    4,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::Int,   10,
    QMetaType::Void, QMetaType::Float, QMetaType::Float,    2,    2,
    QMetaType::Void, QMetaType::Bool,   13,

       0        // eod
};

void Svg2GcodeP::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Svg2GcodeP *_t = static_cast<Svg2GcodeP *>(_o);
        switch (_id) {
        case 0: _t->SvgToGcode((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 1: _t->SetGcoderHeader((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->SetLaser((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->SetgGcodeWidth((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->SetSpeed((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2]))); break;
        case 5: _t->SetCloseLine((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject Svg2GcodeP::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_Svg2GcodeP.data,
      qt_meta_data_Svg2GcodeP,  qt_static_metacall, 0, 0}
};


const QMetaObject *Svg2GcodeP::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Svg2GcodeP::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Svg2GcodeP.stringdata))
        return static_cast<void*>(const_cast< Svg2GcodeP*>(this));
    return QWidget::qt_metacast(_clname);
}

int Svg2GcodeP::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 6;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
