/****************************************************************************
** Meta object code from reading C++ file 'ba_easyform.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "E:/mlaser/mLaser1.0/MLaser/UICompment/ba_easyform.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ba_easyform.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_BA_EasyForm_t {
    QByteArrayData data[14];
    char stringdata[189];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_BA_EasyForm_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_BA_EasyForm_t qt_meta_stringdata_BA_EasyForm = {
    {
QT_MOC_LITERAL(0, 0, 11),
QT_MOC_LITERAL(1, 12, 6),
QT_MOC_LITERAL(2, 19, 0),
QT_MOC_LITERAL(3, 20, 11),
QT_MOC_LITERAL(4, 32, 6),
QT_MOC_LITERAL(5, 39, 6),
QT_MOC_LITERAL(6, 46, 6),
QT_MOC_LITERAL(7, 53, 6),
QT_MOC_LITERAL(8, 60, 22),
QT_MOC_LITERAL(9, 83, 18),
QT_MOC_LITERAL(10, 102, 20),
QT_MOC_LITERAL(11, 123, 21),
QT_MOC_LITERAL(12, 145, 21),
QT_MOC_LITERAL(13, 167, 21)
    },
    "BA_EasyForm\0Sig_BA\0\0Sig_Preview\0slotMa\0"
    "slotMb\0slotMc\0slotMd\0on_btnBackHome_clicked\0"
    "on_btnNext_clicked\0on_btnPannel_clicked\0"
    "on_btnAddText_clicked\0on_btnSetHome_clicked\0"
    "on_btnMateril_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_BA_EasyForm[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   74,    2, 0x06 /* Public */,
       3,    0,   77,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,   78,    2, 0x08 /* Private */,
       5,    0,   79,    2, 0x08 /* Private */,
       6,    0,   80,    2, 0x08 /* Private */,
       7,    0,   81,    2, 0x08 /* Private */,
       8,    0,   82,    2, 0x08 /* Private */,
       9,    0,   83,    2, 0x08 /* Private */,
      10,    0,   84,    2, 0x08 /* Private */,
      11,    0,   85,    2, 0x08 /* Private */,
      12,    0,   86,    2, 0x08 /* Private */,
      13,    0,   87,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void BA_EasyForm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        BA_EasyForm *_t = static_cast<BA_EasyForm *>(_o);
        switch (_id) {
        case 0: _t->Sig_BA((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->Sig_Preview(); break;
        case 2: _t->slotMa(); break;
        case 3: _t->slotMb(); break;
        case 4: _t->slotMc(); break;
        case 5: _t->slotMd(); break;
        case 6: _t->on_btnBackHome_clicked(); break;
        case 7: _t->on_btnNext_clicked(); break;
        case 8: _t->on_btnPannel_clicked(); break;
        case 9: _t->on_btnAddText_clicked(); break;
        case 10: _t->on_btnSetHome_clicked(); break;
        case 11: _t->on_btnMateril_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (BA_EasyForm::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&BA_EasyForm::Sig_BA)) {
                *result = 0;
            }
        }
        {
            typedef void (BA_EasyForm::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&BA_EasyForm::Sig_Preview)) {
                *result = 1;
            }
        }
    }
}

const QMetaObject BA_EasyForm::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_BA_EasyForm.data,
      qt_meta_data_BA_EasyForm,  qt_static_metacall, 0, 0}
};


const QMetaObject *BA_EasyForm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BA_EasyForm::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_BA_EasyForm.stringdata))
        return static_cast<void*>(const_cast< BA_EasyForm*>(this));
    return QWidget::qt_metacast(_clname);
}

int BA_EasyForm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void BA_EasyForm::Sig_BA(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void BA_EasyForm::Sig_Preview()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}
QT_END_MOC_NAMESPACE
